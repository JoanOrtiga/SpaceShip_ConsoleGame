Pràctica de: JOAN ORTIGA BALCELLS

Features LamterEngine:
-Engine propi, amb custom buffer a la consola. Elimina el flickering i redueix drawcalls.
-Sistema de input propi. (GetKeyDown, GetKeyUp, GetKey).
-Sistema de time propi, que assegura que l'engine s'executi a X fps.
-Principi de sistema de components.
-Component de collider, i sistema de colisions.
-Funcions útils com GetGameObjectOfTypeByTag que et retornen un punter d'un tipus o altre segons el tipus enviat i la tag.
-El usuari del engine només escribint el main ja funcionaria tot, sense necessitar implementar pràcticament res.
-Implementació de lectura i escritura de XML amb tinyxml2.
-(...)

Features Joc:
-Moviment de nau lliure.
-2 tipus d'enemic
-Diferents velocitats de dibuixat.
-Spawn d'enemics:
	-Rondes
	-Grups d'enemics i moments en el que fa spawn (permet crear patrons molt ràpid).
		-Enemics: tipus d'enemic, delay entre spawns, posició i quantitat.
-Totes les features obligatories, com explosions, puntuació, lectura de fitxers,


