#pragma once

#define GET_VARIABLE_NAME(Variable) (#Variable)