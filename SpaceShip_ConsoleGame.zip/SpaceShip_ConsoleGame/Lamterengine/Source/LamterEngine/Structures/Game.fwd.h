#pragma once

namespace Lamter
{
	class Game;
}
