#pragma once

class Object
{
};