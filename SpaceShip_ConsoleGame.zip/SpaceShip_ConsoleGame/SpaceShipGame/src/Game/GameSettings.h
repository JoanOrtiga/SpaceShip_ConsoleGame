#pragma once

class GameSettings
{
	static constexpr char saveFileDir[] = "Data/Score";
	static constexpr char readSaveFileDir[] = "Data/Score";
	static constexpr char enemyWavesDir[] = "Data/enemies";
};

