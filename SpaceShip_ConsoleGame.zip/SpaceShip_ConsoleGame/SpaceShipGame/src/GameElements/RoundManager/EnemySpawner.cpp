#include "EnemySpawner.h"

Lamter::Game* EnemySpawner::game;